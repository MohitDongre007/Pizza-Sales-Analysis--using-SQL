-- Determine the top 3 most ordered pizza types based on revenue for each pizza category.


select name, revenue from
(select category, name, revenue, 
rank() over(partition by category order by revenue desc) as rnk
from 
(select a.category, a.name, sum(b.price * c.quantity) as revenue from pizza_types a 
join pizzas b
on a.pizza_type_id = b.pizza_type_id
join order_details c
on c.pizza_id = b.pizza_id
group by a.category, a.name) as x) as y
where rnk <= 3;