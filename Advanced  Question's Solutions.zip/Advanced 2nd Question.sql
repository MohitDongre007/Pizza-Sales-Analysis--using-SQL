-- Analyze the cumulative revenue generated over time.


select order_date, sum(revenue) over(order by order_date) as cum_revenue
from
(select c.order_date, sum(a.price * b.quantity) as revenue from pizzas a 
join order_details b
on a.pizza_id = b.pizza_id
join orders c
on c.order_id = b.order_id
group by c.order_date) as sales;