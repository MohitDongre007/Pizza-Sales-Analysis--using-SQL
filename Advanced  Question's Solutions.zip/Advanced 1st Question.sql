-- Calculate the percentage contribution of each pizza type to total revenue.


SELECT 
    c.category,
    ROUND(SUM(a.price * b.quantity) / (SELECT 
                    ROUND(SUM(a.price * b.quantity), 2)
                FROM
                    pizzas a
                        JOIN
                    order_details b ON a.pizza_id = b.pizza_id) * 100,
            2) AS revenue
FROM
    pizzas a
        JOIN
    order_details b ON a.pizza_id = b.pizza_id
        JOIN
    pizza_types c ON c.pizza_type_id = a.pizza_type_id
GROUP BY c.category
ORDER BY revenue DESC;