-- Group the orders by date and calculate the average number of pizzas ordered per day.


SELECT 
		ROUND(AVG(quantity),0)
FROM
    (SELECT 
        a.order_date, SUM(b.quantity) AS quantity
    FROM
        orders a
    JOIN order_details b ON 
    a.order_id = b.order_id
    GROUP BY a.order_date) AS order_quantity;
