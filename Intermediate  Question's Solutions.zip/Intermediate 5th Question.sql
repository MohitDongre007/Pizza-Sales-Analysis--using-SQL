-- Determine the top 3 most ordered pizza types based on revenue.

select c.name, sum(a.price * b.quantity) as total_revenue from pizzas a join 
order_details b 
on a.pizza_id = b.pizza_id
join pizza_types c
on c.pizza_type_id = a.pizza_type_id
group by c.name
order by total_revenue desc
limit 3;