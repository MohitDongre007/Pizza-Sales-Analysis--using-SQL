-- Join the necessary tables to find the total quantity of each pizza category ordered.


SELECT 
    a.category, SUM(c.quantity) AS Quantity
FROM
    pizza_types a
        JOIN
    pizzas b ON a.pizza_type_id = b.pizza_type_id
        JOIN
    order_details c ON c.pizza_id = b.pizza_id
GROUP BY a.category
ORDER BY quantity DESC;