-- Calculate the total revenue generated from pizza sales.

SELECT 
    ROUND(SUM(a.price * b.quantity), 2) AS total_revenue
FROM
    pizzas AS a
        JOIN
    order_details b ON a.pizza_id = b.pizza_id;
