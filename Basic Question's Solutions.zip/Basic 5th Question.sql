-- List the top 5 most ordered pizza types along with their quantities.


SELECT 
    a.name, SUM(c.quantity) AS quantity
FROM
    pizza_types a
        JOIN
    pizzas b ON a.pizza_type_id = b.pizza_type_id
        JOIN
    order_details c ON c.pizza_id = b.pizza_id
GROUP BY a.name
ORDER BY quantity DESC
LIMIT 5;