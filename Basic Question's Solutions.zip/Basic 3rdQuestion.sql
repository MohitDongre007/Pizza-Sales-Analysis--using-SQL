-- Identify the highest-priced pizza.

SELECT 
    a.name, b.price
FROM
    pizza_types a
        JOIN
    pizzas b ON a.pizza_type_id = b.pizza_type_id
ORDER BY b.price DESC
LIMIT 1;