-- Identify the most common pizza size ordered.


SELECT 
    a.size, COUNT(b.order_details_id) AS order_count
FROM
    pizzas a
        JOIN
    order_details b ON a.pizza_id = b.pizza_id
GROUP BY a.size
ORDER BY order_count DESC;